<?php 
$server_name = "localhost";
$username = "root";
$password = "";
$database_name = "mocktest";
$con = mysqli_connect($server_name , $username , $password , $database_name);
?>