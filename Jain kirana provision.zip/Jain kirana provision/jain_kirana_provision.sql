-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 20, 2022 at 11:15 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jain_kirana_provision`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(10) NOT NULL,
  `admin_name` varchar(255) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_pass` varchar(255) NOT NULL,
  `admin_contact` varchar(255) NOT NULL,
  `admin_job` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `admin_email`, `admin_pass`, `admin_contact`, `admin_job`) VALUES
(1, 'Ajay Jain', 'ajay@gmail.com', '123456', '2255887744', 'Owner');

-- --------------------------------------------------------

--
-- Table structure for table `boxes_section`
--

CREATE TABLE `boxes_section` (
  `box_id` int(10) NOT NULL,
  `box_title` text NOT NULL,
  `box_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(255) NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(10) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_pass` varchar(255) NOT NULL,
  `customer_country` text NOT NULL,
  `customer_city` text NOT NULL,
  `customer_contact` varchar(255) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_image` text NOT NULL,
  `customer_ip` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `customer_name`, `customer_email`, `customer_pass`, `customer_country`, `customer_city`, `customer_contact`, `customer_address`, `customer_image`, `customer_ip`) VALUES
(7, 'user', 'user@gmail.com', '123456', 'India', 'balaghat', '1231451355', 'balaghat , madhya pradesh', 'jain_provision_logo.png', '::1');

-- --------------------------------------------------------

--
-- Table structure for table `customer_orders`
--

CREATE TABLE `customer_orders` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `due_amount` int(100) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_date` date NOT NULL,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `manufacturers`
--

CREATE TABLE `manufacturers` (
  `manufacturer_id` int(10) NOT NULL,
  `manufacturer_title` text NOT NULL,
  `manufacturer_top` text NOT NULL,
  `manufacturer_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `manufacturers`
--

INSERT INTO `manufacturers` (`manufacturer_id`, `manufacturer_title`, `manufacturer_top`, `manufacturer_image`) VALUES
(8, 'Haldiram', 'yes', 'haldiram.png'),
(9, 'Britannia', 'yes', 'Britannia.png'),
(10, 'Parle', 'yes', 'parle.png');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(10) NOT NULL,
  `invoice_no` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `payment_mode` text NOT NULL,
  `ref_no` int(10) NOT NULL,
  `code` int(10) NOT NULL,
  `payment_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pending_orders`
--

CREATE TABLE `pending_orders` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `invoice_no` int(10) NOT NULL,
  `product_id` text NOT NULL,
  `qty` int(10) NOT NULL,
  `size` text NOT NULL,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(10) NOT NULL,
  `p_cat_id` int(10) NOT NULL,
  `manufacturer_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `product_title` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_img3` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_keywords` text NOT NULL,
  `product_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `p_cat_id`, `manufacturer_id`, `date`, `product_title`, `product_img1`, `product_img2`, `product_img3`, `product_price`, `product_keywords`, `product_desc`) VALUES
(18, 6, 8, '2022-04-08 12:06:09', 'Namkeen - Bhujia Sev 1 kg', 'Bhujia Sev 1.jpg', 'Bhujia Sev 3.jpg', 'Bhujia Sev 2.jpg', 240, 'namkeen', '<p><span style=\"color: #333333; font-family: Arial, sans-serif; font-size: small;\">Bhujia Sev is a mildly spicy and deep fried sev made from tepary bean and gram flour. This savoury accompaniment adds texture and seasoning to classic Indian snacks like Upma, Poha and Chaat. This delightful Bhujia Sev can also be eaten as an individual tea-time snack.</span></p>'),
(20, 6, 8, '2022-04-08 14:40:07', 'Namkeen - Aloo Bhujia 1 kg', 'aloo_bhujia_1.webp', 'aloo_bhujia_2.webp', 'aloo_bhujia_3.webp', 220, 'namkeen', '<p>aloo bhujia</p>'),
(21, 6, 8, '2022-04-09 16:55:31', 'Namkeen - Moong Dal 1 kg', 'moong_dal_1.webp', 'moong_dal_2.webp', 'moong_dal_3.webp', 250, 'namkeen', '<p><span style=\"color: #4d5156; font-family: arial, sans-serif;\">Split&nbsp;</span><span style=\"font-weight: bold; color: #5f6368; font-family: arial, sans-serif;\">moong</span><span style=\"color: #4d5156; font-family: arial, sans-serif;\">&nbsp;beans coated in a delectable selection of spices</span></p>'),
(22, 6, 8, '2022-04-09 17:25:21', 'Namkeen - Khatta Meetha 1 kg', 'khatta_meetha_1.webp', 'khatta_meetha_1.webp', 'khatta_meetha_1.webp', 180, 'namkeen', ''),
(23, 6, 8, '2022-04-09 17:11:54', 'Namkeen - Navratan Mix 1 kg', 'navratan_mix_1.webp', 'navratan_mix_2.webp', 'navratan_mix_4.webp', 280, 'namkeen', ''),
(24, 6, 8, '2022-04-16 18:33:32', 'Namkeen - Lemon Bhel (150gms)', 'lemon_bhel_1.webp', 'lemon_bhel_2.webp', 'ing_lemon_3.webp', 30, 'Namkeen', 'Lip-smacking Bhel Puri in a tangy avatar! The citrusy juice of fresh lemons whipped into a combination of crackly bhel, chana and crispy sev. Serve with chopped tomatoes and onions for a delicious evening snack.'),
(25, 6, 8, '2022-04-16 18:36:10', 'Namkeen - Punjabi Tadka (150 gms)', 'punjabi_1.webp', 'punjabi_2.webp', 'panjabi_3.webp', 35, 'Namkeen', 'Crunchy gram flour sticks enhanced with the goodness of ground coriander, jeera and garam masala. Classic sev featuring a Punjabi twist, this wholesome snack is the perfect teatime companion!'),
(26, 6, 8, '2022-04-16 18:37:18', 'Namkeen - Ratlami Sev (150 gms)', 'ratlami_sev_1.webp', 'ratlami_sev_2.webp', 'ratlami_sev_3.webp', 34, 'Namkeen', 'Crispy, fried sticks made with nutritious chickpea flour and a signature blend of Haldiram\'s finest spices. A unique twist on the classic flavours of Bikaner, Ratlami Sev is an ideal teatime companion on its own, or top it on upma, sprout salads and poha for that extra kick of flavour.'),
(27, 7, 9, '2022-04-16 18:56:50', 'Britannia Milk Bikis Biscuits - 200g Pack', 'britania_milk_1.jpg', 'britania_milk_2.jpg', 'britania_milk_3.jpg', 25, 'Biscuit', 'The Britannia Milk Bikis Biscuits 200g is ideal for the children and it is rich in nutrients that are good for their health. This biscuit is made with essential vitamins, iodine and iron.'),
(29, 7, 9, '2022-04-17 17:16:05', 'Treat Jim Jam Cream Sandwich  (150 g)', 'treat-jim-jam-1.webp', 'treat-jim-jam-2.webp', 'treat-jim-jam-3.webp', 25, 'Biscuit', '<p>With every bite of the thick vanilla cream crisp biscuit, Britannia Treat Jim Jam, relive the best memories of your childhood. Along with vanilla cream, it has jam and sugar crystals dusted delicately to leave your taste buds craving for more.</p>'),
(30, 7, 9, '2022-04-17 16:45:48', 'BRITANNIA Bourbon Biscuits Cream Sandwich  (100 g)', 'bourbon-1.webp', 'bourbon-2.webp', 'bourbon-3.webp', 20, 'Biscuit', 'The Bourbon biscuit is a sandwich biscuit consisting of two thin rectangular dark chocolate-flavoured biscuits with a chocolate buttercream filling.'),
(31, 7, 9, '2022-04-17 16:51:51', 'BRITANNIA Good Day Choco Chip Cookies  (100 g)', 'good_day_1.jpg', 'good_day_2.jpg', 'good_day_3.jpg', 25, 'Biscuit', 'The all-time favourite, the classic butterlicious flavour of Britannia Good Day cookies only get better with time. The goodness of rich butter melts in mouth effortlessly, giving a cookie that’s loved by everyone. These crumbly cookies are the best partner when you crave munchies between meals.'),
(32, 7, 9, '2022-04-17 16:54:42', 'Britannia 50-50 Sweet & Salty Biscuits, 40g, Light Brown', '50-50_1.jpg', '50-50_2.jpg', '50-50_3.jpg', 10, 'Biscuit', 'Britannia 50-50 Maska Chaska Salted Biscuits are prepared with the goodness of butter and peppered with the choicest of ingredients. Crunchy and crispy, these biscuits have a light, savoury taste with buttery flavours. Britannia biscuits, cookies, cakes and rusk are a perfect companion for your tea. Believing in delivering fresh and healthy products, Britannia India manufactures some of India\'s favourite brands like Good Day, Tiger, NutriChoice, Bourbon, Milk Bikis and Marie Gold.'),
(33, 7, 9, '2022-04-17 17:38:18', 'Britannia Marie Gold Biscuits , 120g', 'marie_gold_1.jpg', 'marie_gold_2.webp', 'marie_gold_3.webp', 19, 'Biscuit', 'Britannia Marie Gold, one of India’s most iconic biscuit brands fuels homemakers to \'do more & be more\'. The Indian homemaker takes pride in who she is and how she manages the entire household but also has ambitions of her own. As her enabler, friend & a guide, Britannia Marie Gold nudges her to take first steps towards achieving her ambitions.'),
(34, 7, 10, '2022-04-17 18:02:09', 'Parle Krack Jack Biscuit, 69.3g-', 'krack_jack_1.jpg', 'krack_jack_2.jpg', 'krack_jack_3.jpg', 10, 'Biscuit', 'Krack Jack Biscuits are salty and crispy.The crunchy biscuits are sure to leave you impressed.The biscuits are also very sweet in flavour.'),
(35, 7, 10, '2022-04-17 18:08:06', 'Parle G Glucose Biscuit, 100+10g Free=110g', 'parle_G_1.jpg', 'parle_G_1.jpg', 'parle_G_2.jpg', 10, 'Biscuit', 'Filled with glucose,Parle G Gluco Gold biscuits are made from the best quality wheat flour.A treat for one and all. An instant filler for all age groups.The Sweet flavour and the Crunchiness of the biscuits is a hit with all age groups.'),
(36, 8, 0, '2022-04-18 18:01:12', 'Rin Detergent Bar, 145g', 'soap_rin_1.jpg', 'soap_rin_2.jpg', 'soap_rin_3.webp', 10, 'Soap', ''),
(37, 8, 0, '2022-04-18 18:02:37', 'Ghadi Detergent Cake, 185g', 'soap_ghadi_1.jpg', 'soap_ghadi_1.jpg', 'soap_ghadi_1.jpg', 10, 'Soap', ''),
(38, 8, 0, '2022-04-19 17:15:18', 'Dettol Soap Bar (Buy 4 Get 1 Free - 75g each', 'soap_dettol_1.jpg', 'soap_dettol_2.jpg', 'soap_dettol_3.jpg', 145, 'Soap', ''),
(39, 8, 0, '2022-04-19 17:13:43', 'Savlon Glycerine Soap, 125g (Buy 3 Get 1 Free)', 'soap_savlon_1.jpg', 'soap_savlon_2.jpg', 'soap_savlon_3.jpg', 141, 'Soap', ''),
(40, 8, 0, '2022-04-19 17:16:04', 'Medimix 18 Herbs Soap, 125 g (4 + 1 Offer Pack)', 'soap_medimix_1.jpg', 'soap_medimix_2.jpg', 'soap_medimix_3.jpg', 172, 'Soap', ''),
(41, 9, 0, '2022-04-19 17:31:15', 'Fortune Kachi Ghani Mustard Oil Pouch  (1 L)', 'oil-fortune-1.webp', 'oil-fortune-2.webp', 'oil-fortune-3.webp', 174, 'Oil', ''),
(42, 9, 0, '2022-04-19 17:32:54', 'Gold Winner Refined Sunflower Oil Pouch  (1 L)', 'oil-gold-1.webp', 'oil-gold-2.webp', 'oil-gold-3.webp', 185, 'Oil', ''),
(43, 9, 0, '2022-04-19 17:36:30', 'Navratna Ayurvedic Cool Hair Oil  (300 ml)', 'oil-navratna-1.webp', 'oil-navratna-1.webp', 'oil-navratna-2.webp', 106, 'Oil', ''),
(44, 9, 0, '2022-04-19 17:46:17', 'Parachute Jasmine Coconut Hair Oil (400 ml)', 'oil-jasmin-1.webp', 'oil-jasmin-2.webp', 'oil-jasmin-3.webp', 164, 'Oil', ''),
(45, 9, 0, '2022-04-19 17:45:42', 'Organic India Organic Mustard Oil - (1000ml)', 'oil-oragnic-1.jpg', 'oil-oragnic-2.jpg', 'oil-oragnic-3.jpg', 320, 'Oil', ''),
(46, 10, 0, '2022-04-19 17:53:34', 'Dry Grass Broom Stick (Phool Jhadu)', 'jhadu-1.jpg', 'jhadu-1.jpg', 'jhadu-2.jpg', 120, 'Jhadu', '');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `p_cat_id` int(10) NOT NULL,
  `p_cat_title` text NOT NULL,
  `p_cat_top` text NOT NULL,
  `p_cat_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`p_cat_id`, `p_cat_title`, `p_cat_top`, `p_cat_image`) VALUES
(6, 'Namkeen', 'yes', 'snacks.jpg'),
(7, 'Biscuits', 'yes', 'Biscuits.jpg'),
(8, ' Shop and Detergent', 'no', 'soap.jpg'),
(9, 'Oil', 'yes', ''),
(10, 'General merchandise', 'no', '');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slide_id` int(10) NOT NULL,
  `slide_name` varchar(255) NOT NULL,
  `slide_image` text NOT NULL,
  `slide_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slide_id`, `slide_name`, `slide_image`, `slide_url`) VALUES
(15, 'Slide 1', 'slide_1.jpg', ''),
(16, 'Slide 2', 'slide_4.jpg', ''),
(17, 'Slide 3', 'slide_5.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `term_id` int(10) NOT NULL,
  `term_title` varchar(100) NOT NULL,
  `term_link` varchar(100) NOT NULL,
  `term_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `boxes_section`
--
ALTER TABLE `boxes_section`
  ADD PRIMARY KEY (`box_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `manufacturers`
--
ALTER TABLE `manufacturers`
  ADD PRIMARY KEY (`manufacturer_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `pending_orders`
--
ALTER TABLE `pending_orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`p_cat_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slide_id`);

--
-- Indexes for table `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`term_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `boxes_section`
--
ALTER TABLE `boxes_section`
  MODIFY `box_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customer_orders`
--
ALTER TABLE `customer_orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `manufacturers`
--
ALTER TABLE `manufacturers`
  MODIFY `manufacturer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pending_orders`
--
ALTER TABLE `pending_orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `p_cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `slide_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `terms`
--
ALTER TABLE `terms`
  MODIFY `term_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
