-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2022 at 11:07 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cee_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_acc`
--

CREATE TABLE `admin_acc` (
  `admin_id` int(11) NOT NULL,
  `admin_user` varchar(1000) NOT NULL,
  `admin_pass` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_acc`
--

INSERT INTO `admin_acc` (`admin_id`, `admin_user`, `admin_pass`) VALUES
(1, 'admin@username', 'admin@password');

-- --------------------------------------------------------

--
-- Table structure for table `course_tbl`
--

CREATE TABLE `course_tbl` (
  `cou_id` int(11) NOT NULL,
  `cou_name` varchar(1000) NOT NULL,
  `cou_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_tbl`
--

INSERT INTO `course_tbl` (`cou_id`, `cou_name`, `cou_created`) VALUES
(1, 'INFORMATION TECHNOLOGY', '2022-04-02 07:45:26');

-- --------------------------------------------------------

--
-- Table structure for table `examinee_tbl`
--

CREATE TABLE `examinee_tbl` (
  `exmne_id` int(11) NOT NULL,
  `exmne_fullname` varchar(1000) NOT NULL,
  `exmne_course` varchar(1000) NOT NULL,
  `exmne_gender` varchar(1000) NOT NULL,
  `exmne_email` varchar(1000) NOT NULL,
  `exmne_password` varchar(1000) NOT NULL,
  `exmne_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `examinee_tbl`
--

INSERT INTO `examinee_tbl` (`exmne_id`, `exmne_fullname`, `exmne_course`, `exmne_gender`, `exmne_email`, `exmne_password`, `exmne_status`) VALUES
(1, 'abc', '1', 'male', 'abc@gmail.com', '11111', 'active'),
(2, 'xyz', '1', 'male', 'xyz@gmail.com', '11111', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_answers`
--

CREATE TABLE `exam_answers` (
  `exans_id` int(11) NOT NULL,
  `axmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `quest_id` int(11) NOT NULL,
  `exans_answer` varchar(1000) NOT NULL,
  `exans_status` varchar(1000) NOT NULL DEFAULT 'new',
  `exans_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_answers`
--

INSERT INTO `exam_answers` (`exans_id`, `axmne_id`, `exam_id`, `quest_id`, `exans_answer`, `exans_status`, `exans_created`) VALUES
(337, 1, 1, 59, 'Meandering', 'old', '2022-04-02 08:54:55'),
(338, 1, 1, 50, 'Flyer', 'old', '2022-04-02 08:54:55'),
(339, 1, 1, 54, 'Praiseworthy', 'old', '2022-04-02 08:54:55'),
(340, 1, 1, 82, 'jeer', 'old', '2022-04-02 08:54:55'),
(341, 1, 1, 74, '4/15', 'old', '2022-04-02 08:54:55');

-- --------------------------------------------------------

--
-- Table structure for table `exam_attempt`
--

CREATE TABLE `exam_attempt` (
  `examat_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `examat_status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `exam_question_tbl`
--

CREATE TABLE `exam_question_tbl` (
  `eqt_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `exam_question` varchar(1000) NOT NULL,
  `exam_ch1` varchar(1000) NOT NULL,
  `exam_ch2` varchar(1000) NOT NULL,
  `exam_ch3` varchar(1000) NOT NULL,
  `exam_ch4` varchar(1000) NOT NULL,
  `exam_answer` varchar(1000) NOT NULL,
  `exam_status` varchar(1000) NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_question_tbl`
--

INSERT INTO `exam_question_tbl` (`eqt_id`, `exam_id`, `exam_question`, `exam_ch1`, `exam_ch2`, `exam_ch3`, `exam_ch4`, `exam_answer`, `exam_status`) VALUES
(43, 1, 'Ten friends planned to share equally the cost of buying a gift for their teacher. When two of them decided not to contribute, each of the other friends had to pay Rs 150 more. The cost of the gift was Rs. _____.', '12000', '666', '3000', '6000', '6000', 'active'),
(44, 1, 'The expenditure on the project _____ as follows; equipment Rs.20 lakhs, salaries Rs.12 lakhs, and contingency Rs.3 lakhs.', 'Break down', 'Break', 'Breaks down', 'Breaks', 'Breaks down', 'active'),
(45, 1, 'Two cars start at the same time from the same location and go in the same direction. The speed of the first car is 50 Km/h and the speed of the second car is 60 Km/h. The number of hours it takes for the distance between the two cars to be 20 Km is _____.', '2', '3', '1', '6', '2', 'active'),
(46, 1, 'A court is to a judge as _____ is to a teacher.', 'A syllabus', 'A student', 'A punishment', 'A school', 'A school', 'active'),
(47, 1, 'In a college, there are three student clubs. Sixty students are only in the Drama club, 80 students are only in the Dance club, 30 students are only in the Maths club, 40 students are in both Drama and Dance clubs, 12 students are in both Dance and Maths clubs, 7 students are in both Drama and Maths club, and 2 students are in all the clubs. If 75% of the students in the college are not in any of these clubs, then the total number of students in the college is _____.', '900', '975', '225', '1000', '900', 'active'),
(48, 1, '.\"A recent High Court judgement has sought to dispel the idea of begging as a disease — which leads to its stigmatization and criminalization — and to regard it as a symptom. The underlying disease is the failure of the state to protect citizens who fall through the social security net.\"Which of the following statements can be inferred from the given passage?', 'Beggars are created because of the lack of social welfare schemas', 'Beggars are lazy people who beg because they are unwilling to work', 'Begging is an offence that has to be dealt with the family', 'Begging has to be banned because it adversely affects the welfare pf the state', 'Beggars are created because of the lack of social welfare schemas', 'active'),
(49, 1, 'Goods and Services Tax (GST) is an indirect tax introduced in India in 2017 that is imposed on the supply of goods and services, and it subsumes all indirect taxes except few. It is a destination-based tax imposed on goods and services used, and it is not imposed at the point of origin from where goods come. GST also has a few components specific to state governments, central government and Union Territories (UTs). Which one of the following statements can be inferred from the given passage?', 'GST includes all indirect taxes', 'GST is imposed at the point of usage of good and services', 'GST does not have a component specific to UT', 'GST is imposed on the production of good and services', 'GST is imposed at the point of usage of good and services', 'active'),
(50, 1, 'Select the word that fits the analogy: Cook : Cook :: Fly : _____', 'Flyer', 'Flying', 'Flew', 'Fighter', 'Flyer', 'active'),
(51, 1, 'The drawn of the 21st century witnessed the melting glaciers oscillating between giving too much and too little to billions of people who depend on them for fresh water. The UN climate report estimates that without deep cuts to man-made emissions, at least 30% of the northern hemisphere’s surface permafrost could melt by the end of the century. Given this situation of imminent global exodus of billions of people displaced by rising seas, nation-states need to rethink their carbon footprint for political concerns, if not for environmental ones. Which one of the following statements can be inferred from the given passage', 'Nation-states are responsible for providing fresh water to billions of people', 'Billions of people are affected by melting glaciers', 'Nation-states do not have environmental concern', 'Billions of people are responsible for man-made emissions', 'AnswerBillions of people are affected by melting glaciers', 'active'),
(52, 1, 'Raman is confident of speaking English _____ six months as he has been practising regularly____the last three weeks', 'For, in', 'During, for', 'For, since', 'Within, for', 'Within, for', 'active'),
(53, 1, 'If P = 3, R = 27, T = 243, then Q+S = ______.', '80', '110', '40', '90', '90', 'active'),
(54, 1, 'His knowledge of the subject was excellent but his classroom performance was ______.', 'Good ', 'Praiseworthy', 'Extremely poor', 'Desirable', 'Extremely poor', 'active'),
(55, 1, 'In a party, 60% of the invited guests are male and 40% are female. If 80% of the invited guests attended the party and if all the invited female guests attended, what would be the ratio of males to females among the attendees in the party?', '2:3', '1:1', '3:2', '2:1', '1:1', 'active'),
(56, 1, 'In appreciation of the social improvements completed in a town, a wealthy philanthropist decided to gift Rs 750 to each male senior citizen in the town and Rs 1000 to each female senior citizen. Altogether, there were 300 senior citizens eligible for this gift. However, only 8/9th of the eligible men and 2/3rd of the eligible women claimed the gift. How much money (in Rupees) did the philanthropist give away in total?', '1,50,000', '2,00,000', '1,75,000', '1,51,000', '2,00,000', 'active'),
(57, 1, 'A sixsided unbiased die with four green faces and two red faces is rolled seven times. Which of the following combinations is the most likely outcome of the experiment?', 'Three green faces and four red faces', 'Four green faces and three red faces', 'Five green faces and two red faces', 'Six green faces and one red face', 'Five green faces and two red faces', 'active'),
(58, 1, '.“From where are they bringing their books? __________ bringing __________ books from __________.” The words that best fill the blanks in the above sentence are', 'Their, they’re, there', 'They’re, their, there ', 'their, there, They’re', 'They’re, there, there', 'They’re, their, there', 'active'),
(59, 1, '\"A _______investigation can sometimes yield new facts, but typically organized ones are more successful.\" The word that best fills the blank in the above sentence is', 'Meandering', 'Timely', 'Consistent', 'Systematic', 'Meandering', 'active'),
(60, 1, 'What is the missing number in the following sequence?2, 12, 60, 240, 720, 1440, _______, 0 ', '2880', '1440', '720', '0', '1440', 'active'),
(61, 1, 'What would be the smallest natural number which when divided either by 20 or by 42 or by 76 leaves a remainder of \"7\" in each case?', '3047', '6047', '7987', '63847', '7987', 'active'),
(62, 1, 'After RajendraChola returned from his voyage to Indonesia, he _________ to visit the temple in Thanjavur.', 'Was wishing', 'Is wishing', 'Wished', 'Had wished', 'Wished', 'active'),
(64, 1, 'Research in the workplace reveals that people work for many reason __________.', 'Money beside', 'Beside money', 'Money besides', 'Besides money', 'Besides money', 'active'),
(65, 1, 'Rahul, Murali, Srinivas and Arul are seated around a square table. Rahul is sitting to the left of Murali,Srinivas is sitting to the right of Arul. Which of the following pairs are seated opposite each other?', 'Rahul and Murali', 'Srinivas and arul', 'Srivinas, Murali', 'Srivinas and Rahul', 'Srivinas, Murali', 'active'),
(66, 1, 'Find the smallest number y such that y × 162 is a prefect cube.', '24', '27', '32', '36', '36', 'active'),
(67, 1, 'Two straight lines are drawn perpendicular to each other in X-Y plane. If a and b are the acute angles the straight lines make with the X-axis, then a+b is ______.', '60 degree', '120 degree', '180 degree', '90 degree', '90 degree', 'active'),
(68, 1, 'Six people are seated around a circular table. There are atleast two men and two women. There are at least three right-handed persons. Every woman has a left-handed person to her immediate right. None of the women are right-handed. The number of women at the table is', '2', '3', '4', 'Cannot be determined', '2', 'active'),
(69, 1, 'Arun, Gulab, Neel and Shweta must choose one shirt each from a pile of four shirts coloured red, pink, blue and white respectively. Arun dislikes the colour red and Shweta dislikes the colour white. Gulab and Neel like all the colours. In how many different ways can they choose the shirts so that no one has a shirt with a colour he or she likes?', '21', '18', '16', '14', '14', 'active'),
(70, 1, 'Choose the option with words that are not synonyms.', 'Aversion ,dislike', 'Luminous, radiant', 'Plunder, loot', 'Yielding, resistant', 'Yielding, resistant', 'active'),
(71, 1, 'Saturn is __________ to be seen on a clear night with the naked eye.', 'Enough bright', 'Bright enough', 'As enough bright', 'Bright as enough', 'Bright enough', 'active'),
(72, 1, 'There are five buildings called V, W, X, Y and Z in a row (not necessarily in that order). V is to the West of W, Z is to the East of X and the West of V, W is to the West of Y. Which is the building in the middle?', 'V', 'W', 'X', 'Y', 'V', 'active'),
(73, 1, 'A test has twenty questions worth 100 marks in total. There are two types of questions. Multiple choice questions are worth 3 marks each and essay questions are worth 11 marks each. How many multiple choice questions does the exam have?', '12', '15', '18', '19', '15', 'active'),
(74, 1, 'There are 3 red socks, 4 green socks and 3 blue socks. You choose 2 socks. The probability that they are of the same colour is', '1/5', '7/30', '1/4', '4/15', '4/15', 'active'),
(75, 1, 'X is a 30 digit number starting with the digit 4 followed by the digit 7. Then the number X3 will have', '90 Digits', '91 Digits', '92 Digits', '93 Digits', '90 Digits', 'active'),
(76, 1, 'The number of roots of ex + 0.5x2 – 2 in the range [-5, 5] is', '0', '1', '2', '3', '2', 'active'),
(77, 1, 'A rewording of something written or spoken is a ______________.', 'Paraphrase', 'Paradox', 'Paradigm', 'paraffin', 'Paraphrase', 'active'),
(78, 1, 'Archimedes said, “Give me a lever long enough and a fulcrum on which to place it, and I will move the world.” The sentence above is an example of a ___________ statement.', 'Figurative', 'Collateral', 'Literal', 'figurine', 'Figurative', 'active'),
(79, 1, 'A cube is built using 64 cubic blocks of side one unit. After it is built, one cubic block is removed from every corner of the cube. The resulting surface area of the body (in square units) after the removal is __________.', '56', '64', '72', '96', '96', 'active'),
(80, 1, 'In a process, the number of cycles to failure decreases exponentially with an increase in load. At a load of 80 units, it takes 100 cycles for failure. When the load is halved, it takes 10000 cycles for failure. The load for which the failure will happen in 5000 cycles is ________.', '40.0', '46.02', '60.01', '92.02', '46.02', 'active'),
(81, 1, 'Nobody knows how the Indian cricket team is going to cope with the difficult and seamer-friendly wickets in Australia. Choose the option which is closest in meaning to the underlined phrase in the above sentence.', 'Put up with', 'Put in with', 'Put down to', 'Put up against', 'Put in with', 'active'),
(82, 1, 'Find the odd one in the following group of words. mock,   deride,   praise,   jeer', 'Mock', 'Deride', 'Praise', 'jeer', 'Praise', 'active'),
(83, 1, 'Pick the odd one from the following options.', 'CADBE', 'JHKIL', 'XVYWZ', 'ONPMQ', 'ONPMQ', 'active'),
(84, 1, 'The probabilities that a student passes in Mathematics, Physics and Chemistry are m, p and c respectively. Of these subjects, the student has 75% chance of passing in at least one, a 50% chance of passing in at least two and a 40% chance of passing in exactly two. Following relations are drawn in m, p, c: (I) p + m + c = 27/20 (II) p + m + c = 13/20 (III) (p) × (m) × (c) = 1/10', 'Only relation I is true', 'Only relation II is true', 'Relation II and III are true', 'Relation I and III are true', 'Relation I and III are true', 'active'),
(85, 1, 'A generic term that include various items of clothing such as a skirt, a pair of trousers and a shirt is', 'Fabric', 'Textile', 'Fibre', 'Apparel', 'Apparel', 'active'),
(86, 1, 'Given set A = {2, 3, 4, 5} and Set B = {11, 12, 13, 14, 15}, two numbers are randomly selected, one from each set. What is probability that the sum of the two numbers equals 16?', '0.20', '0.25', '0.30', '0.33', '0.20', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `exam_tbl`
--

CREATE TABLE `exam_tbl` (
  `ex_id` int(11) NOT NULL,
  `cou_id` int(11) NOT NULL,
  `ex_title` varchar(1000) NOT NULL,
  `ex_time_limit` varchar(1000) NOT NULL,
  `ex_questlimit_display` int(11) NOT NULL,
  `ex_description` varchar(1000) NOT NULL,
  `ex_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `exam_tbl`
--

INSERT INTO `exam_tbl` (`ex_id`, `cou_id`, `ex_title`, `ex_time_limit`, `ex_questlimit_display`, `ex_description`, `ex_created`) VALUES
(1, 1, 'Aptitude and Reasoining', '30', 20, 'A logical reasoning test measures your ability or aptitude to reason logically. Generally, logical reasoning tests measure non-verbal abilities. You must, through logical and abstract reasoning, extract rules, analogies and structures which you subsequently use to find a correct answer among a set of possible options.', '2022-04-02 09:02:45'),
(31, 1, 'Data Structure', '30', 20, 'Data Structure is an important topic in the GATE CSE question paper, and solving these questions will help the candidates to prepare more proficiently for the GATE exams.', '2022-04-02 09:06:05');

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks_tbl`
--

CREATE TABLE `feedbacks_tbl` (
  `fb_id` int(11) NOT NULL,
  `exmne_id` int(11) NOT NULL,
  `fb_exmne_as` varchar(1000) NOT NULL,
  `fb_feedbacks` varchar(1000) NOT NULL,
  `fb_date` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_acc`
--
ALTER TABLE `admin_acc`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `course_tbl`
--
ALTER TABLE `course_tbl`
  ADD PRIMARY KEY (`cou_id`);

--
-- Indexes for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  ADD PRIMARY KEY (`exmne_id`);

--
-- Indexes for table `exam_answers`
--
ALTER TABLE `exam_answers`
  ADD PRIMARY KEY (`exans_id`);

--
-- Indexes for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  ADD PRIMARY KEY (`examat_id`);

--
-- Indexes for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  ADD PRIMARY KEY (`eqt_id`);

--
-- Indexes for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  ADD PRIMARY KEY (`ex_id`);

--
-- Indexes for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  ADD PRIMARY KEY (`fb_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_acc`
--
ALTER TABLE `admin_acc`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `course_tbl`
--
ALTER TABLE `course_tbl`
  MODIFY `cou_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `examinee_tbl`
--
ALTER TABLE `examinee_tbl`
  MODIFY `exmne_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `exam_answers`
--
ALTER TABLE `exam_answers`
  MODIFY `exans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=342;

--
-- AUTO_INCREMENT for table `exam_attempt`
--
ALTER TABLE `exam_attempt`
  MODIFY `examat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `exam_question_tbl`
--
ALTER TABLE `exam_question_tbl`
  MODIFY `eqt_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `exam_tbl`
--
ALTER TABLE `exam_tbl`
  MODIFY `ex_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `feedbacks_tbl`
--
ALTER TABLE `feedbacks_tbl`
  MODIFY `fb_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
