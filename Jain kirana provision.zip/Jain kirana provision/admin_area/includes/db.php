<?php 

$con = mysqli_connect("localhost","root","","jain_kirana_provision");

?>